
import React from 'react';
import { render } from 'react-dom';
import Chart from './../charts/charts';
import { Layout, Menu, Button,Radio } from 'antd';
const {Footer } = Layout;
class Footer extends React.Component {

 
	render() {
		return (
            <Footer style={{ textAlign: 'center',marginTop: 64, }}>exir @ 2022</Footer>
			
		
		)
	}
}
export default Footer;
